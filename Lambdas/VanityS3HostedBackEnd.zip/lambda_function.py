import json
import boto3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    phone_number = event['queryStringParameters']['phoneNumber']
    logger.info(f"Received phone number: {phone_number}")

    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('CustomerVanityNumbers')

    try:
        response = table.get_item(Key={'PhoneNumber': phone_number})
        logger.info(f"DynamoDB response: {response}")

        if 'Item' in response:
            item = response['Item']
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'message': 'Success',
                    'data': item
                })
            }
        else:
            return {
                'statusCode': 404,
                'headers': {
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'message': 'No vanity numbers found for this phone number.'
                })
            }
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'message': 'Error retrieving data',
                'error': str(e)
            })
        }
