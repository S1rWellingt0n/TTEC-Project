import json
import boto3
import urllib.request

# Initialize the DynamoDB client
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('CustomerVanityNumbers')

def get_word_definition(word):
    url = f'https://api.dictionaryapi.dev/api/v2/entries/en/{word}'
    try:
        with urllib.request.urlopen(url) as response:
            if response.status == 200:
                definition_data = json.loads(response.read().decode())
                definition = definition_data[0]['meanings'][0]['definitions'][0]['definition']
                return definition
    except Exception as e:
        print(f"Error getting definition for word {word}: {e}")
    return "Definition not found"

def format_vanity_number(vanity_number):
    # Format the phone number by spacing out each digit and word
    formatted_number = ' '.join([char if char.isdigit() else char for char in vanity_number])
    return formatted_number

def lambda_handler(event, context):
    full_phone_number = event.get('Details', {}).get('ContactData', {}).get('CustomerEndpoint', {}).get('Address', '')
    phone_number = full_phone_number.lstrip('+1')  # Remove leading '+' and country code '1'

    try:
        response = table.get_item(Key={'PhoneNumber': phone_number})
        if 'Item' in response:
            item = response['Item']

            response_data = {"statusCode": 200}
            prompt_message = "Your phone number has three vanity numbers."

            for i in range(1, 4):  # Assuming we need the top three vanity numbers
                vanity_key = f'vanityNumber{i}'
                if vanity_key in item:
                    word = ''.join([char for char in item[vanity_key] if char.isalpha()])
                    definition = get_word_definition(word)
                    formatted_vanity_number = ' '.join(item[vanity_key])

                    prompt_message += f" Number {i} is {formatted_vanity_number}, matched with the word '{word}' which means '{definition}'."
                    response_data[f'vanityNumber{i}'] = formatted_vanity_number
                    response_data[f'word{i}'] = word
                    response_data[f'definition{i}'] = definition

            response_data["body"] = json.dumps({"message": prompt_message})

            return response_data
        else:
            return {
                "statusCode": 404,
                "body": json.dumps({"error": "Phone number not found in the database."})
            }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }