import boto3
import pandas as pd
import logging
from collections import defaultdict
from io import StringIO
import json

# Initialize the S3 and DynamoDB clients
s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('CustomerVanityNumbers')

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Mapping of letters to numbers, including leet and visual similarities
INVERSE_PHONE_DICT = {
    "a": "2", "b": "8", "c": "2", "d": "3", "e": "3", "f": "3",
    "g": "9", "h": "4", "i": "1", "j": "7", "k": "2", "l": "1",
    "m": "3", "n": "2", "o": "0", "p": "9", "q": "9", "r": "2",
    "s": "5", "t": "7", "u": "0", "v": "2", "w": "3", "x": "8",
    "y": "4", "z": "2"
}

def parse_dictionary(bucket_name, file_key):
    logger.info(f"Fetching file {file_key} from bucket {bucket_name}")
    s3_object = s3_client.get_object(Bucket=bucket_name, Key=file_key)
    file_content = s3_object['Body'].read().decode('utf-8')

    logger.info("Parsing dictionary from file content")
    words_df = pd.read_csv(StringIO(file_content), header=None, names=['WORD'])
    words_df['WORD'] = words_df['WORD'].astype(str).str.lower()

    # Generate a dictionary of words and their numeric representations
    word_numbers = {}
    for word in words_df['WORD']:
        numeric_representation = ''.join(INVERSE_PHONE_DICT.get(char, char) for char in word)
        word_numbers[numeric_representation] = word

    return word_numbers

def generate_vanity_numbers(phone_number, word_numbers):
    logger.info(f"Generating vanity numbers for phone number {phone_number}")
    matches = []

    for num_rep, word in word_numbers.items():
        if num_rep in phone_number:
            start_index = phone_number.find(num_rep)
            end_index = start_index + len(num_rep)
            vanity_number = phone_number[:start_index] + word.upper() + phone_number[end_index:]
            matches.append((len(word), {'vanityNumber': vanity_number, 'matchedWord': word}))

    # Sort matches based on the length of the matched word (score), descending order
    matches.sort(reverse=True, key=lambda x: x[0])

    # Select top 5 matches
    top_matches = [match[1] for match in matches[:5]]

    return top_matches

def lambda_handler(event, context):
    logger.info("Lambda function started")
    bucket_name = 'textbuck3456252435'
    file_key = 'words.csv'

    phone_number = event['Details']['ContactData']['CustomerEndpoint']['Address'][-10:]
    logger.info(f"Extracted phone number: {phone_number}")

    word_numbers = parse_dictionary(bucket_name, file_key)

    top_matches = generate_vanity_numbers(phone_number, word_numbers)

    # Store the matches in DynamoDB
    logger.info("Storing matches in DynamoDB")
    vanity_data = {}
    for i, match in enumerate(top_matches, 1):
        vanity_data[f'vanityNumber{i}'] = match['vanityNumber']

    table.put_item(
        Item={
            'PhoneNumber': phone_number,
            **vanity_data
        }
    )

    logger.info("Lambda function execution completed")

    # Prepare the response in the expected format for Amazon Connect
    response = {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps({'matches': top_matches})
    }

    return response
